<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="Stylesheet.css">
</head>
<body>
<a href="mijn%20profiel.php">terug naar mijn profiel</a>


</body>
</html>

