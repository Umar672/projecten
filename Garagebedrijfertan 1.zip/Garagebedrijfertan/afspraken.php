<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="Stylesheet.css">
</head>
<body class="afspraken">
    <a href="mijn%20profiel.php">terug naar mijn profiel</a>
    <table>
        <tr>
            <th>Kenteken</th>
            <th>Klant</th>
            <th>In garage</th>
            <th>Service status</th>
        </tr>
        <tr>
            <td>04-JDK-9</td>
            <td>Ömer Eryigit</td>
            <td>Ja</td>
            <td>In de wacht</td>
        </tr>
        <tr>
            <td>37-TVR-1</td>
            <td>Poenai</td>
            <td>Ja</td>
            <td>In behandeling</td>
        </tr>
        <tr>
            <td>37-TVR-1</td>
            <td>Sandra van Vliet</td>
            <td>Ja</td>
            <td>In de wacht</td>
        </tr>
        <tr>
            <td>37-TVR-1</td>
            <td>Mo efes</td>
            <td>Ja</td>
            <td>In de wacht</td>
        </tr>
        <tr>
            <td>37-TVR-1</td>
            <td>Nikola N</td>
            <td>Ja</td>
            <td>In behandeling</td>
        </tr>
    </table>
</body>
</html>
