<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="Stylesheet.css">
</head>
<body>
    <footer class= "footer">

            <h3>BEL ONS DIRECT</h3>
            <p>
    Tel: 010-85625312<br>
                Tel: 06-42309032<br>
                Tel: 06-40958865
    </p>

            <a href="https://www.facebook.com/">Facebook</a>
            <a href="https://www.instagram.com/">Instagram</a>
            <a href="https://twitter.com/">Twitter</a>
            <a href="https://nl.linkedin.com/">linkedin</a>
            <p>copyright@</p>
        </footer>
</body>
</html>