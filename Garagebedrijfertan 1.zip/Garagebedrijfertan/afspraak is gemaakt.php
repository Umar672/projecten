<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="Stylesheet.css">
</head>
<body>
    <h1> Uw afspraak wordt verwerkt.</h1>
    <h2> U ontvangt binnenkort van ons een bevestiging per e-mail</h2>
    <a href="index.php"> Klik hier om terug te gaan naar de homepagina</a>
</body>
</html>